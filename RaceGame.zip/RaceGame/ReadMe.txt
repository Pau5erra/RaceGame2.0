Instructions:

R = restart.

Up/right/left/down = car control